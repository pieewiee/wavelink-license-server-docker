Wavelink Client License Server  --  Read Me File

Copyright (C) 2010 Wavelink Corporation.  All rights reserved.
==========================================================================

The material provided in this document is in addition to and/or
supersedes the information available in the License Server user manual.



==========================================================================
Installation
==========================================================================

Wavelink Client License Server ships with platform-specific installation
utilities.  The following information can be used for manual
installations.



==========================================================================
Command Line Options (All platforms)
==========================================================================

-c <configfile>   Configuration file to use. Default: LicenseServer.cfg.
-d                Run as a daemon (Linux/UNIX only).
-h                Usage Info.
-l <loglevel>     Set logging level 0..4 (0=everything, 4=severe errors only)
                  Default: 2
-n                Run as a console application, not as a service (Windows only)
-p <user> <pass>  HTTP service username and password
-t                Terminate running service or daemon
-u                Uninstall service (Windows only)
-v                Show program version details.
-w <homedir>      Home directory to use.



==========================================================================
LicenseServer.log
==========================================================================

Wavelink Client License Server maintains a log file named "LicenseServer.log"
in the current working directory.  License Server will automatically open a new
log file when the current one grows larger than the size specified in the
configuration file.  (The default is 1000000 bytes.)  These continuation log
files are named "LicenseServer.log.1", "LicenseServer.log.2" and so on.  



==========================================================================
Site ID Support
==========================================================================

Site ID support allows you to assign numeric values to devices so that
licensing can be performed more granularly.  When a device has been assigned a
particular Site ID, it can only be assigned licenses with that same Site ID
value or a Site ID value of 0.  This allows you to have one or more license
servers that will restrict which licenses a device can be assigned.

These settings are new to License Server 4.1.  Telnet clients 7.0.54 and later,
and 7.1.15 and later, support this functionality.

Before assigning Site IDs to licenses, make sure that all the License
Servers you will be synchronizing with are also upgraded to version 4.1 or
later.  Otherwise, you may lose the Site ID values during synchronization.



==========================================================================
Windows Service Operation
==========================================================================

Wavelink Client License Server prefers to be run as a service.  The service
is enabled during installation, and set to start automatically.  You can
control the service from the Windows Services manager, or by running
LicenseServer.exe and using the command-line flags to stop or uninstall the
service.  Running LicenseServer.exe without any flags will verify that the
service is installed and running.

If you want to run Wavelink Client License Server as a console application,
instead of as a service, run LicenseServer.exe with the /n flag.  This will
stop the service (if it is running), and start an interactive version of
LicenseServer.exe.



==========================================================================
Linux/UNIX Operation
==========================================================================

Wavelink Client License Server can be run interactively or as a daemon.



==========================================================================
AIX Restart Information
==========================================================================

The /etc/inittab file is used at startup to launch processes as the AIX system
starts. In order for Wavelink Client License Server to launch at startup, an
inittab entry needs to be added.

To add an inittab entry:

1. Please make a copy of your current inittab file before you make any changes. 

2. Use this AIX command line to add the necessary entry to the inittab file:
  mkitab "wlcls:2:once:/opt/wavelink/wlcls/LicenseServer -w /opt/wavelink/wlcls -d" 

This command will add the following entry to your inittab file:
  wlcls:2:once:/opt/wavelink/wlcls/LicenseServer -w /opt/wavelink/wlcls -d

Entry Breakdown:
  Identifier - wlcls
  Runlevel   - 2
  Action     - once
  Command    - /opt/wavelink/wlcls/LicenseServer -w /opt/wavelink/wlcls -d

Command Breakdown:
  Program with full path - /opt/wavelink/wlcls/LicenseServer
  Home directory to use  - -w /opt/wavelink/wlcls
  Run as a daemon        - -d

3. Note these additional command to list, remove, and edit the inittab wlcls entry.
  * Use lsitab -a to view all inittab entries.
  * Use rmitab "wlcls" to remove the wlcls entry.
  * Use chitab "Enter modified entry here".
    Example of Runlevel changed from 2 to 3:
      chitab "wlcls:3:once:/opt/wavelink/wlcls/LicenseServer -w /opt/wavelink/wlcls -d"



==========================================================================
Logging Levels
==========================================================================

The logging level controls the amount of information written to the
log file.  It can be expressed as either a numeric value or a mnemonic
keyword.

4       CRITICAL       (Errors only)
3       WARNING        (Errors + Warnings)
2       INFO           (Errors + Warnings + Informational)
1       VERBOSE        (INFO + information for diagnosing issues)
0       EVERYTHING     (VERBOSE + network traffic logging)
